from xorq.vendor.ibis.backends.trino import Backend as IbisTrinoBackend


class Backend(IbisTrinoBackend):
    pass
